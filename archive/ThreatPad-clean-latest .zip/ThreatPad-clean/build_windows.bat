@echo off
echo Building ThreatPad for Windows...

:: Install/upgrade all dependencies first
echo Installing/updating dependencies...
python -m pip install --upgrade pyinstaller tkinterdnd2

:: Get the tkinterdnd2 package location so PyInstaller can find its DLLs
for /f "delims=" %%i in ('python -c "import tkinterdnd2, os; print(os.path.dirname(tkinterdnd2.__file__))"') do set TKDND_PATH=%%i
echo tkinterdnd2 path: %TKDND_PATH%

:: Build the Windows executable with custom icon
echo Building executable...
pyinstaller --onefile --windowed --name=ThreatPad --clean ^
    --collect-all tkinterdnd2 ^
    --hidden-import tkinterdnd2 ^
    --icon=threatpad.ico ^
    threatpad.py

:: Check if build was successful
if not exist "dist\ThreatPad.exe" (
    echo.
    echo ================================
    echo BUILD FAILED!
    echo ================================
    echo Check the output above for errors.
    pause
    exit /b 1
)

echo.
echo ================================
echo BUILD SUCCESSFUL!
echo ================================
echo Executable created: dist\ThreatPad.exe
dir dist\ThreatPad.exe

:: ── CODE SIGNING (OPTIONAL) ──────────────────────────────────────────────────
:: To sign the executable, place your .pfx certificate file in this folder,
:: set CERT_FILE to its filename, and set CERT_PASSWORD to your password.
:: Then un-comment the block below.
::
:: Requirements: signtool.exe must be on your PATH.
:: It ships with the Windows SDK — install via Visual Studio Installer
:: or download the standalone Windows SDK from Microsoft.
::
:: ─────────────────────────────────────────────────────────────────────────────
:: set CERT_FILE=your_certificate.pfx
:: set CERT_PASSWORD=your_password_here
:: set TIMESTAMP_URL=http://timestamp.digicert.com
::
:: echo Signing executable...
:: signtool sign ^
::     /f "%CERT_FILE%" ^
::     /p "%CERT_PASSWORD%" ^
::     /tr "%TIMESTAMP_URL%" ^
::     /td sha256 ^
::     /fd sha256 ^
::     dist\ThreatPad.exe
::
:: if %ERRORLEVEL% neq 0 (
::     echo WARNING: Signing failed. The executable is built but unsigned.
:: ) else (
::     echo Signing successful.
::     signtool verify /pa dist\ThreatPad.exe
:: )
:: ─────────────────────────────────────────────────────────────────────────────

echo.
echo The executable is ready: dist\ThreatPad.exe
pause
