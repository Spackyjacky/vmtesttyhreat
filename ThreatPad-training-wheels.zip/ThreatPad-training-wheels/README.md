# ThreatPad

A SOC (Security Operations Center) incident notes application built for cybersecurity analysts. Handles IOC (Indicators of Compromise) detection, defanging, enrichment, and documentation in a multi-tab editor.

---

## Requirements

- Python 3.7+
- Dependencies listed in `requirements.txt`

```bash
pip install -r requirements.txt
```

**Optional:** Install `pyspellchecker` for spell checking:
```bash
pip install pyspellchecker
```

---

## Running

```bash
python threatpad.py
```

---

## Features

- **Multi-tab editor** with syntax highlighting for IOCs
- **Defang / Refang**: Neutralise IOCs for safe sharing — supports IPs, domains, URLs, emails, `#`, and `@` adjacent to `#`
- **Extract IOCs**: Automatically identifies IPv4/IPv6, domains, URLs, emails, MD5/SHA1/SHA256 hashes
- **IOC Enrichment**: Optional threat intelligence lookups via VirusTotal, AbuseIPDB, ip-api.com, and vpnapi.io
- **Safe Copy**: Warns before copying undefanged IOCs
- **Templates & Snippets**: Pre-built incident response templates and quick-insert Copy Pasta snippets
- **Hashing**: Generate and identify MD5, SHA1, SHA256 hashes
- **Base64 Encode / Decode**
- **Find / Replace**
- **Dark mode** with system theme detection
- **Session restore**: Automatically saves and restores open tabs
- **Drag & drop** file loading
- **Auto-save** for open files

---

## Keyboard Shortcuts

| Action | Shortcut |
|---|---|
| New tab | Ctrl+N |
| Open file | Ctrl+O |
| Save | Ctrl+S |
| Save as | Ctrl+Shift+S |
| Close tab | Ctrl+W |
| Defang IOCs | Ctrl+D |
| Refang IOCs | Ctrl+R |
| Extract IOCs | Ctrl+I |
| Export IOCs | Ctrl+E |
| Enrich IOCs | Ctrl+Shift+E |
| Find | Ctrl+F |
| Find & Replace | Ctrl+H |
| Undo | Ctrl+Z |
| Redo | Ctrl+Y |
| Increase font | Ctrl++ |
| Decrease font | Ctrl+- |
| Quit | Ctrl+Q |

Tabs can also be closed by clicking the **✕** in the tab label, or by middle-clicking the tab.

---

## IOC Enrichment Setup

Enrichment uses a mix of free APIs (no key needed) and optional paid/free-tier APIs:

| Service | Key required | Limit |
|---|---|---|
| ip-api.com (geolocation) | No | 45 req/min |
| vpnapi.io (VPN detection) | No | 1,000 req/day |
| VirusTotal | Yes (free) | 4 req/min |
| AbuseIPDB | Yes (free) | 1,000 req/day |

Add API keys under **Tools → Settings → API Keys**.

- VirusTotal key: https://www.virustotal.com/gui/my-apikey
- AbuseIPDB key: https://www.abuseipdb.com/api

---

## Building a Standalone Executable

### Windows
```cmd
build_windows.bat
```

### macOS / Linux
```bash
chmod +x build.sh
./build.sh
```

### With spell checker excluded (smaller build)
```bash
python build_no_spellcheck.py
```

### Manual
```bash
pip install pyinstaller
pyinstaller --onefile --windowed --name=ThreatPad --clean threatpad.py
```

Output is placed in the `dist/` folder. The executable is fully standalone — no Python installation needed on the target machine.

> **Note:** Executables built on macOS will not run on Windows and vice versa. Build on the target platform, or use GitHub Actions for cross-platform builds.

---

## Runtime Files

These files are created automatically in the working directory at runtime — they are not required to run the app:

| File | Purpose |
|---|---|
| `session.json` | Saves open tabs and content for restore on next launch |
| `app_settings.json` | User preferences (theme, font, etc.) |
| `copy_pasta_snippets.json` | Custom Copy Pasta snippets |
| `recent_files.txt` | Recent file history |
| `custom_dict.txt` | Custom spell check words (optional) |
| `templates.json` | Saved templates (optional) |

---

## Project Structure

```
threatpad.py              # Main application
ioc_enrichment.py         # IOC enrichment module (VirusTotal, AbuseIPDB, etc.)
requirements.txt          # Python dependencies
setup.py                  # Package setup
build_exe.py              # PyInstaller build script (with spell check)
build_no_spellcheck.py    # PyInstaller build script (without spell check)
build_windows.bat         # Windows build script
build.sh                  # macOS/Linux build script
README.md                 # This file
app_settings.json         # Default/saved app settings
copy_pasta_snippets.json  # Default/saved snippets
```

---

## License

MIT
