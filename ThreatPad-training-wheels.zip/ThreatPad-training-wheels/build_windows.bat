@echo off
echo Building ThreatPad for Windows...

:: Install/upgrade all dependencies
echo Installing/updating dependencies...
python -m pip install --upgrade pyinstaller tkinterdnd2

:: Get tkinterdnd2 path so PyInstaller bundles the right DLLs
for /f "delims=" %%i in ('python -c "import tkinterdnd2, os; print(os.path.dirname(tkinterdnd2.__file__))"') do set TKDND_PATH=%%i
echo tkinterdnd2 path: %TKDND_PATH%

:: Build
echo Building executable...
pyinstaller --onefile --windowed --name=ThreatPad --clean ^
    --collect-all tkinterdnd2 ^
    --hidden-import tkinterdnd2 ^
    --icon=threatpad.ico ^
    threatpad.py

if not exist "dist\ThreatPad.exe" (
    echo BUILD FAILED - check output above
    pause & exit /b 1
)

echo.
echo ================================================
echo  BUILD SUCCESSFUL:  dist\ThreatPad.exe
echo ================================================

:: ── CODE SIGNING (optional) ──────────────────────────────────────────────────
::
::  Requirements:
::    - A code signing certificate (.pfx file) in this folder
::    - signtool.exe on your PATH  (ships with the Windows SDK)
::      Download: https://developer.microsoft.com/windows/downloads/windows-sdk/
::
::  To enable signing:
::    1. Place your .pfx file in this folder
::    2. Fill in CERT_FILE and CERT_PASSWORD below
::    3. Remove the leading "::" from each line in this section
::
:: set CERT_FILE=your_certificate.pfx
:: set CERT_PASSWORD=your_password_here
:: set TIMESTAMP_URL=http://timestamp.digicert.com
::
:: echo Signing executable...
:: signtool sign /f "%CERT_FILE%" /p "%CERT_PASSWORD%" /tr "%TIMESTAMP_URL%" /td sha256 /fd sha256 dist\ThreatPad.exe
::
:: if %ERRORLEVEL% neq 0 (
::     echo WARNING: Signing failed. Executable is built but unsigned.
:: ) else (
::     echo Signing successful.
::     signtool verify /pa dist\ThreatPad.exe
::     echo Verification complete.
:: )
::
:: ─────────────────────────────────────────────────────────────────────────────

echo.
echo The executable is ready: dist\ThreatPad.exe
pause
