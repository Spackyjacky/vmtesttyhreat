#!/usr/bin/env python3
"""
Drop this in the same folder as your threatpad.py and run:
    python fix_threatpad.py

Fixes all common corruption from markdown rendering:
- Smart/curly quotes  -> straight ASCII quotes
- Em dashes / en dashes -> hyphens
- **init** style broken dunders -> __init__
- Any other non-ASCII punctuation
"""
import os, ast, shutil

TARGET = "threatpad.py"

if not os.path.exists(TARGET):
    print(f"ERROR: {TARGET} not found in current directory.")
    exit(1)

with open(TARGET, 'r', encoding='utf-8', errors='replace') as f:
    src = f.read()

# Back up original
shutil.copy(TARGET, TARGET + ".bak")
print(f"Backup saved as {TARGET}.bak")

fixes = {
    '\u201c': '"',   # left double quote
    '\u201d': '"',   # right double quote
    '\u2018': "'",   # left single quote
    '\u2019': "'",   # right single quote
    '\u201a': "'",   # single low-9 quote
    '\u201e': '"',   # double low-9 quote
    '\u2014': '--',  # em dash
    '\u2013': '-',   # en dash
    '\u2026': '...', # ellipsis
    '\u00ab': '"',   # left angle quote
    '\u00bb': '"',   # right angle quote
    '\u2032': "'",   # prime
    '\u2033': '"',   # double prime
    '\u00b4': "'",   # acute accent
    '\u0060': "'",   # grave accent used as quote
}

dunder_fixes = [
    ('**init**',     '__init__'),
    ('**new**',      '__new__'),
    ('**del**',      '__del__'),
    ('**str**',      '__str__'),
    ('**repr**',     '__repr__'),
    ('**len**',      '__len__'),
    ('**name**',     '__name__'),
    ('**main**',     '__main__'),
    ('**class**',    '__class__'),
    ('**dict**',     '__dict__'),
    ('**module**',   '__module__'),
]

total = 0

for bad, good in fixes.items():
    n = src.count(bad)
    if n:
        print(f"  Fixed {n:>4}x  U+{ord(bad):04X} {repr(bad):12s}  ->  {repr(good)}")
        total += n
        src = src.replace(bad, good)

for bad, good in dunder_fixes:
    n = src.count(bad)
    if n:
        print(f"  Fixed {n:>4}x  {bad!r:20s}  ->  {good!r}")
        total += n
        src = src.replace(bad, good)

print(f"\nTotal replacements: {total}")

# Verify it parses
try:
    ast.parse(src)
    print("Syntax check: PASSED")
    with open(TARGET, 'w', encoding='utf-8') as f:
        f.write(src)
    print(f"Saved clean file as {TARGET}")
except SyntaxError as e:
    print(f"Syntax check: FAILED at line {e.lineno}: {e.msg}")
    print("File NOT saved. Check the .bak file.")
    lines = src.splitlines()
    for i in range(max(0, e.lineno-3), min(len(lines), e.lineno+3)):
        print(f"  {i+1}: {lines[i]}")
