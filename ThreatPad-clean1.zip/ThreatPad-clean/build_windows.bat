@echo off
echo Building ThreatPad for Windows...

:: Install/upgrade all dependencies first
echo Installing/updating dependencies...
python -m pip install --upgrade pyinstaller tkinterdnd2

:: Get the tkinterdnd2 package location so PyInstaller can find its DLLs
for /f "delims=" %%i in ('python -c "import tkinterdnd2, os; print(os.path.dirname(tkinterdnd2.__file__))"') do set TKDND_PATH=%%i
echo tkinterdnd2 path: %TKDND_PATH%

:: Build the Windows executable
:: --collect-all tkinterdnd2 pulls in all DLLs and data files for tkinterdnd2
:: --hidden-import ensures the module is included even if not auto-detected
echo Building executable...
pyinstaller --onefile --windowed --name=ThreatPad --clean ^
    --collect-all tkinterdnd2 ^
    --hidden-import tkinterdnd2 ^
    threatpad.py

:: Check if build was successful
if exist "dist\ThreatPad.exe" (
    echo.
    echo ================================
    echo BUILD SUCCESSFUL!
    echo ================================
    echo Executable created: dist\ThreatPad.exe
    dir dist\ThreatPad.exe
    echo.
    echo The executable is ready for deployment!
) else (
    echo.
    echo ================================
    echo BUILD FAILED!
    echo ================================
    echo Check the output above for errors.
)

pause
